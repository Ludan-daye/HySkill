#!/bin/bash
# E0 recompute on the GPU server. One tag at a time. Stop on the first failed gate.
set -u
cd /root/hyskill-ijcai27
export HF_ENDPOINT=https://hf-mirror.com
export HUGGINGFACE_HUB_ENDPOINT=https://hf-mirror.com
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false
export PYTHONPATH=/root/hyskill-ijcai27:/root/hyskill-ijcai27/external/SR-Agents/src
export PYTHONUNBUFFERED=1
export CUDA_VISIBLE_DEVICES=0
PY=/root/hyskill-ijcai27/.venv/bin/python
echo "GPU_CHECK $(date -u +%Y-%m-%dT%H:%M:%SZ)"
"$PY" -c 'import torch; assert torch.cuda.is_available(), "cuda unavailable"; x=torch.zeros(4, device="cuda"); torch.cuda.synchronize(); print("GPU_OK", torch.cuda.get_device_name(0), torch.cuda.get_device_capability(), float(x.sum()))'
TAGS=(deepseek7b glm4-9b llama31-8b mistral7b qwen3.5-4b-reference qwen35-9b yi15-9b)
for tag in "${TAGS[@]}"; do
  echo "RECOMPUTE_START $tag $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  if ! "$PY" scripts/recompute_revision_rankings.py \
    --tag "$tag" \
    --encoder BAAI/bge-base-en-v1.5 \
    --k 2 \
    --corpus external/SR-Agents/data/bench/corpus/corpus.json \
    --instances-dir external/SR-Agents/data/bench/instances \
    --cache "community-results/$tag/imagination_full_k2.jsonl.gz" \
    --emb-cache-dir results/revision-ijcai27/emb-cache \
    --out-metrics "community-results/$tag/revision-ijcai27/metrics_bge-base-en-v1.5.jsonl.gz" \
    --out-rankings "results/revision-ijcai27/$tag/rankings_bge-base-en-v1.5.jsonl.gz"; then
    echo "RECOMPUTE_FAIL $tag $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    exit 1
  fi
  echo "GATE_START $tag $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  if ! "$PY" scripts/check_revision_reproduction.py \
    --tag "$tag" \
    --recomputed-metrics "community-results/$tag/revision-ijcai27/metrics_bge-base-en-v1.5.jsonl.gz" \
    --recomputed-rankings "results/revision-ijcai27/$tag/rankings_bge-base-en-v1.5.jsonl.gz" \
    --published-metrics "community-results/$tag/k-ablation/metrics_long.jsonl.gz" \
    --router "community-results/$tag/k2/router_decisions.json" \
    --output "community-results/$tag/revision-ijcai27/reproduction.json" \
    --community-root community-results; then
    echo "GATE_STOP $tag $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    exit 2
  fi
  echo "GATE_PASS $tag $(date -u +%Y-%m-%dT%H:%M:%SZ)"
done
echo "ALL_GATES_PASSED $(date -u +%Y-%m-%dT%H:%M:%SZ)"
