#!/bin/bash
set -u
cd /root/hyskill-ijcai27
export HF_ENDPOINT=https://hf-mirror.com
export HUGGINGFACE_HUB_ENDPOINT=https://hf-mirror.com
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false
export PYTHONPATH=/root/hyskill-ijcai27:/root/hyskill-ijcai27/external/SR-Agents/src
export PYTHONUNBUFFERED=1
export CUDA_VISIBLE_DEVICES=0
PY=/root/hyskill-ijcai27/.venv/bin/python
for tag in mistral7b qwen3.5-4b-reference qwen35-9b yi15-9b; do
  echo "RECOMPUTE_START $tag $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  "$PY" scripts/recompute_revision_rankings.py \
    --tag "$tag" \
    --encoder sentence-transformers/all-MiniLM-L6-v2 \
    --k 2 \
    --corpus external/SR-Agents/data/bench/corpus/corpus.json \
    --instances-dir external/SR-Agents/data/bench/instances \
    --cache "community-results/$tag/imagination_full_k2.jsonl.gz" \
    --emb-cache-dir results/revision-ijcai27/emb-cache \
    --out-metrics "community-results/$tag/revision-ijcai27/metrics_all-MiniLM-L6-v2.jsonl.gz" \
    --out-rankings "results/revision-ijcai27/$tag/rankings_all-MiniLM-L6-v2.jsonl.gz"
  RC=$?
  echo "RECOMPUTE_RC $tag rc=$RC $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  if [ "$RC" -ne 0 ]; then
    exit "$RC"
  fi
  echo "GATE_START $tag $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  "$PY" scripts/check_revision_reproduction.py \
    --tag "$tag" \
    --encoder sentence-transformers/all-MiniLM-L6-v2 \
    --recomputed-metrics "community-results/$tag/revision-ijcai27/metrics_all-MiniLM-L6-v2.jsonl.gz" \
    --recomputed-rankings "results/revision-ijcai27/$tag/rankings_all-MiniLM-L6-v2.jsonl.gz" \
    --published-metrics "community-results/$tag/k-ablation/metrics_long.jsonl.gz" \
    --router "community-results/$tag/k2/router_decisions.json" \
    --output "community-results/$tag/revision-ijcai27/reproduction.json" \
    --community-root community-results
  GRC=$?
  echo "GATE_DONE $tag gate_rc=$GRC $(date -u +%Y-%m-%dT%H:%M:%SZ)"
done
echo "REM4_SWEEP_FINISHED $(date -u +%Y-%m-%dT%H:%M:%SZ)"
