#!/usr/bin/env bash
set -euo pipefail
cd /root/hyskill-ijcai27

echo "[$(date -u +%FT%TZ)] Waiting for active Wave 1 PIDs (43092, 43093) to finish..."
while kill -0 43092 2>/dev/null || kill -0 43093 2>/dev/null; do
  sleep 5
done
kill -9 6263 2>/dev/null || true

export HF_ENDPOINT=https://hf-mirror.com
export HUGGINGFACE_HUB_ENDPOINT=https://hf-mirror.com
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTHONPATH=.:external/SR-Agents/src

MODELS=(deepseek7b glm4-9b llama31-8b mistral7b qwen3.5-4b-reference qwen35-9b yi15-9b)

for spec in "BAAI/bge-base-en-v1.5=bge-base-en-v1.5" "thenlper/gte-base=gte-base" "BAAI/bge-large-en-v1.5=bge-large-en-v1.5"; do
  enc="${spec%%=*}"
  slug="${spec#*=}"
  echo "=== SEQ ENCODER ${enc} (${slug}) ==="
  for tag in "${MODELS[@]}"; do
    out_m="community-results/${tag}/revision-ijcai27/metrics_${slug}.jsonl.gz"
    out_r="/data/hyskill-ijcai27/rankings/${tag}/rankings_${slug}.jsonl.gz"
    if [[ -f "${out_m}" && -f "${out_m}.manifest.json" && -f "${out_r}" && -f "${out_r}.manifest.json" ]]; then
      echo "[$(date -u +%FT%TZ)] SKIP_DONE ${slug} ${tag}"
      continue
    fi
    mkdir -p "community-results/${tag}/revision-ijcai27" "/data/hyskill-ijcai27/rankings/${tag}"
    echo "[$(date -u +%FT%TZ)] START ${slug} ${tag}"
    .venv/bin/python scripts/recompute_revision_rankings.py \
      --tag "${tag}" \
      --encoder "${enc}" \
      --k 2 \
      --corpus external/SR-Agents/data/bench/corpus/corpus.json \
      --instances-dir external/SR-Agents/data/bench/instances \
      --cache "community-results/${tag}/imagination_full_k2.jsonl.gz" \
      --emb-cache-dir /data/hyskill-ijcai27/emb-cache \
      --out-metrics "${out_m}" \
      --out-rankings "${out_r}"
    echo "[$(date -u +%FT%TZ)] DONE ${slug} ${tag}"
  done
done
echo "=== ALL_E4_SEQ_COMPLETE $(date -u +%FT%TZ) ==="
