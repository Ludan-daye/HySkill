#!/bin/bash
# Guarded resume: relaunch E7 (four models without glm4-9b) and E4 only when absent and unfinished.
cd /data/hyskill-ijcai27
if ! pgrep -f "run_e7_rest4.sh|run_hy_rerank_model_lane.py" >/dev/null && ! grep -q REST4_E7_MODELS_COMPLETE run_e7_rest4.log 2>/dev/null; then echo "RESUME_E7 $(date -u +%FT%TZ)" >> run_e7_rest4.log; setsid bash run_e7_rest4.sh >> run_e7_rest4.log 2>&1 < /dev/null & echo E7_LAUNCHED; fi
if ! pgrep -f "run_e4_seq.sh|recompute_revision_rankings.py" >/dev/null && ! grep -q ALL_E4 run_e4_seq.log 2>/dev/null; then echo "RESUME_E4 $(date -u +%FT%TZ)" >> run_e4_seq.log; setsid bash run_e4_seq.sh >> run_e4_seq.log 2>&1 < /dev/null & echo E4_LAUNCHED; fi
