#!/bin/bash
# Resume the interrupted E7 lane and the E4 sequential recompute.
# E7 starts first so vLLM can reserve its share. E4 starts after that.
set -u
cd /data/hyskill-ijcai27

if pgrep -f 'run_hy_rerank_model_lane.py|recompute_revision_rankings.py' >/dev/null; then
  echo "ALREADY_RUNNING"
  ps -eo pid,etime,cmd | grep -E 'run_hy_rerank_model_lane|recompute_revision_rankings' | grep -v grep
  exit 1
fi

if ! grep -q 'already audited valid=True' hy-rerank-repo/scripts/run_hy_rerank_model_lane.py; then
  echo "REFUSING: lane script has no valid-audit skip"
  exit 1
fi

mark="RESUME $(date -u +%FT%TZ)"
echo "$mark" >> run_e7_all5.log
echo "$mark" >> run_e4_seq.log
e7_from=$(wc -l < run_e7_all5.log)

setsid bash run_e7_all5.sh >> run_e7_all5.log 2>&1 < /dev/null &
echo "E7_PID $!"

ready=0
for _ in $(seq 1 36); do
  sleep 10
  if awk -v n="$e7_from" 'NR>n' run_e7_all5.log | grep -q 'vLLM ready for glm4-9b'; then
    ready=1
    break
  fi
  if awk -v n="$e7_from" 'NR>n' run_e7_all5.log | grep -E -q 'Traceback|CUDA out of memory|Audit valid'; then
    echo "E7_FAILED_BEFORE_READY"
    exit 1
  fi
  if ! pgrep -f 'run_e7_all5.sh|run_hy_rerank_model_lane.py' >/dev/null; then
    echo "E7_DIED_BEFORE_READY"
    exit 1
  fi
done

if [[ "$ready" -ne 1 ]]; then
  echo "E7_NOT_READY_AFTER_WAIT"
  exit 1
fi

setsid bash run_e4_seq.sh >> run_e4_seq.log 2>&1 < /dev/null &
echo "E4_PID $!"
sleep 3
ps -eo pid,ppid,etime,cmd | grep -E 'run_e7_all5|run_e4_seq|run_hy_rerank_model_lane|recompute_revision_rankings' | grep -v grep
echo "LAUNCHED"
