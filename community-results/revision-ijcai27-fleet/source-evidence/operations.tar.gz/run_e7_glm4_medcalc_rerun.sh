#!/bin/bash
# Rerun glm4-9b medcalcbench hy_rerank from scratch after the four-model E7 lane finishes.
cd /data/hyskill-ijcai27
echo "WAIT_START $(date -u +%FT%TZ)"
while pgrep -f "run_e7_rest4.sh|run_hy_rerank_model_lane.py" >/dev/null; do sleep 60; done
if ! grep -q REST4_E7_MODELS_COMPLETE run_e7_rest4.log; then echo "ABORT_REST4_NOT_COMPLETE $(date -u +%FT%TZ)"; exit 1; fi
REPO=/data/hyskill-ijcai27/hy-rerank-repo
PYTHONPATH="${REPO}:${REPO}/external/SR-Agents/src" /data/hyskill-ijcai27/venv-vllm-0191/bin/python -u ${REPO}/scripts/run_hy_rerank_model_lane.py --model-tag glm4-9b --repo-root ${REPO} --result-root /data/hyskill-ijcai27/hy-rerank-results --models-root /root/hyskill-ijcai27/models --vllm-venv /data/hyskill-ijcai27/venv-vllm-0191 --client-python /data/hyskill-ijcai27/venv-vllm-0191/bin/python --port 8000 --gpu-mem-util 0.50 --workers 32 && echo "GLM4_MEDCALC_RERUN_COMPLETE $(date -u +%FT%TZ)"
