#!/usr/bin/env bash
set -euo pipefail
REPO=/data/hyskill-ijcai27/hy-rerank-repo
RES=/data/hyskill-ijcai27/hy-rerank-results
MODELS=/root/hyskill-ijcai27/models
CLIENT_PY=/data/hyskill-ijcai27/venv-vllm-0191/bin/python
mkdir -p "$RES"

run_model() {
  local tag="$1"
  local venv="$2"
  local mem_util="$3"
  echo "[$(date -u +%FT%TZ)] === START E7 MODEL ${tag} (venv=${venv}, util=${mem_util}) ==="
  PYTHONPATH="${REPO}:${REPO}/external/SR-Agents/src" "$CLIENT_PY" -u "${REPO}/scripts/run_hy_rerank_model_lane.py" \
    --model-tag "${tag}" \
    --repo-root "${REPO}" \
    --result-root "${RES}" \
    --models-root "${MODELS}" \
    --vllm-venv "${venv}" \
    --client-python "${CLIENT_PY}" \
    --port 8000 \
    --gpu-mem-util "${mem_util}" \
    --workers 32
  echo "[$(date -u +%FT%TZ)] === DONE E7 MODEL ${tag} ==="
}

run_model glm4-9b /data/hyskill-ijcai27/venv-vllm-0191 0.68
run_model llama31-8b /data/hyskill-ijcai27/venv-vllm-0191 0.50
run_model mistral7b /data/hyskill-ijcai27/venv-vllm-0191 0.50
run_model qwen3.5-4b-reference /data/hyskill-ijcai27/venv-vllm-0171 0.50
run_model qwen35-9b /data/hyskill-ijcai27/venv-vllm-0171 0.50

echo "[$(date -u +%FT%TZ)] === ALL_5_E7_MODELS_COMPLETE ==="
