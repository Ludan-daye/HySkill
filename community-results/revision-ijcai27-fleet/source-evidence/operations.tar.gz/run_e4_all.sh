#!/usr/bin/env bash
set -euo pipefail
cd /root/hyskill-ijcai27
cp -n results/revision-ijcai27/encoders.json results/revision-ijcai27/encoders.e0.json
cp /data/hyskill-ijcai27/encoders/encoders.e4.json results/revision-ijcai27/encoders.json
mkdir -p /data/hyskill-ijcai27/emb-cache /data/hyskill-ijcai27/rankings
cp -n results/revision-ijcai27/emb-cache/*.npz /data/hyskill-ijcai27/emb-cache/ 2>/dev/null || true

export HF_ENDPOINT=https://hf-mirror.com
export HUGGINGFACE_HUB_ENDPOINT=https://hf-mirror.com
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export PYTHONPATH=.:external/SR-Agents/src

run_one() {
  local enc="$1"
  local slug="$2"
  local tag="$3"
  mkdir -p "community-results/${tag}/revision-ijcai27" "/data/hyskill-ijcai27/rankings/${tag}"
  echo "[$(date -u +%FT%TZ)] START ${slug} ${tag}"
  .venv/bin/python scripts/recompute_revision_rankings.py \
    --tag "${tag}" \
    --encoder "${enc}" \
    --k 2 \
    --corpus external/SR-Agents/data/bench/corpus/corpus.json \
    --instances-dir external/SR-Agents/data/bench/instances \
    --cache "community-results/${tag}/imagination_full_k2.jsonl.gz" \
    --emb-cache-dir /data/hyskill-ijcai27/emb-cache \
    --out-metrics "community-results/${tag}/revision-ijcai27/metrics_${slug}.jsonl.gz" \
    --out-rankings "/data/hyskill-ijcai27/rankings/${tag}/rankings_${slug}.jsonl.gz"
  echo "[$(date -u +%FT%TZ)] DONE ${slug} ${tag}"
}

for spec in "BAAI/bge-base-en-v1.5=bge-base-en-v1.5" "thenlper/gte-base=gte-base" "BAAI/bge-large-en-v1.5=bge-large-en-v1.5"; do
  enc="${spec%%=*}"
  slug="${spec#*=}"
  echo "=== ENCODER ${enc} (${slug}) ==="
  # Warm .npz cache single-process first
  run_one "${enc}" "${slug}" "deepseek7b"
  # Wave 1: 3 models in parallel
  run_one "${enc}" "${slug}" "glm4-9b" > "/data/hyskill-ijcai27/rankings/e4_${slug}_glm4-9b.log" 2>&1 &
  p1=$!
  run_one "${enc}" "${slug}" "llama31-8b" > "/data/hyskill-ijcai27/rankings/e4_${slug}_llama31-8b.log" 2>&1 &
  p2=$!
  run_one "${enc}" "${slug}" "mistral7b" > "/data/hyskill-ijcai27/rankings/e4_${slug}_mistral7b.log" 2>&1 &
  p3=$!
  wait "$p1" "$p2" "$p3"
  echo "[$(date -u +%FT%TZ)] WAVE1_DONE ${slug}"
  # Wave 2: 3 models in parallel
  run_one "${enc}" "${slug}" "qwen3.5-4b-reference" > "/data/hyskill-ijcai27/rankings/e4_${slug}_qwen3.5-4b-reference.log" 2>&1 &
  p4=$!
  run_one "${enc}" "${slug}" "qwen35-9b" > "/data/hyskill-ijcai27/rankings/e4_${slug}_qwen35-9b.log" 2>&1 &
  p5=$!
  run_one "${enc}" "${slug}" "yi15-9b" > "/data/hyskill-ijcai27/rankings/e4_${slug}_yi15-9b.log" 2>&1 &
  p6=$!
  wait "$p4" "$p5" "$p6"
  echo "[$(date -u +%FT%TZ)] WAVE2_DONE ${slug}"
done
echo "=== ALL_E4_RECOMPUTES_COMPLETE $(date -u +%FT%TZ) ==="
